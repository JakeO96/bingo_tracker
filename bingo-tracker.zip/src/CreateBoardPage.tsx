import { CreateBoardForm } from "./CreateBoardForm";

export default function HomePage() {
  return (
    <CreateBoardForm />
  );
}