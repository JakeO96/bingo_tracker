import type { BoardTileData } from "../../shared/types/bingo";

export type BingoBoard = BoardTileData[]