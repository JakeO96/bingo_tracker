import { LogInForm } from './LogInForm'

export const LogInPage: React.FC<object> = () => {
  return (
    <LogInForm />
  )
};